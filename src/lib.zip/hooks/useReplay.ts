import { ReplayTick } from "@/lib/events/replay/replay.types";
import { useEffect, useState } from "react";

export function useReplay(ticks: ReplayTick[]) {
  const [mode, setMode] = useState<"live" | "replay">("live");
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);

  // index = СКОЛЬКО ticks уже проиграно
  const [index, setIndex] = useState(0);

  const playedTicks = ticks.slice(0, index);
  const activeTick = index > 0 ? ticks[index - 1] : null;

  // ---- playback loop ----
  useEffect(() => {
    if (mode !== "replay" || !isPlaying) return;
    if (index >= ticks.length) return;

    const delay = 300 / speed;

    const id = setTimeout(() => {
      setIndex((i) => Math.min(i + 1, ticks.length));
    }, delay);

    return () => clearTimeout(id);
  }, [mode, isPlaying, speed, index, ticks.length]);

  // ---- controls ----
  const controls = {
    play: () => setIsPlaying(true),
    pause: () => setIsPlaying(false),

    next: () =>
      setIndex((i) => Math.min(i + 1, ticks.length)),

    prev: () =>
      setIndex((i) => Math.max(i - 1, 0)),

    setSpeed,

    toggleMode: () => {
      setMode((m) => (m === "live" ? "replay" : "live"));
      setIsPlaying(false);
      setIndex(0); // ⬅️ стартуем с "пустого кадра"
    },
  };

  return {
    mode,
    isPlaying,
    speed,
    index,
    playedTicks,
    activeTick,
    controls,
  };
}
