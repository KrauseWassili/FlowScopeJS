import { Marker } from "@/lib/markers";
import { cn } from "@/lib/utils";
import { ObservedEvent } from "@/lib/events/observed/observedEvent.types";
import { ReplayTick } from "@/lib/events/replay/replay.types";
import { formatTimeMs } from "@/lib/utils/formatTimeMs";
import { SYSTEM_NODES } from "@/lib/events/nodes/systemNodes";

type EventTimelineProps = {
  events: ObservedEvent[];
  activeTick: ReplayTick | null;
  mode: "live" | "replay";
  markers: Marker[];
  onJumpToEvent: (traceId: string) => void;
};

function PipelineRail({
  event,
  activeTick,
}: {
  event: ObservedEvent;
  activeTick: ReplayTick | null;
}) {
  return (
    <div className="flex items-end gap-3 min-h-[56px]">
      {SYSTEM_NODES.map((node) => {
        const nodeInfo = event.node[node];

        let colorClass = "bg-inactive";
        if (nodeInfo?.outcome === "error") {
          colorClass = "bg-error";
        } else if (nodeInfo?.outcome === "success") {
          colorClass = "bg-success";
        }

        const isActiveLamp =
          activeTick &&
          activeTick.traceId === event.traceId &&
          activeTick.node === node;

        return (
          <div key={node} className="flex flex-col items-center min-w-[56px]">
            <span className="text-[10px] text-gray-400 mb-1">
              {node.toUpperCase()}
            </span>

            <span
              className={cn(
                "w-3 h-3 rounded-full transition-all",
                colorClass,
                isActiveLamp && "ring-2 ring-amber-400 scale-125"
              )}
            />

            <span className="text-[10px] text-gray-500 min-h-[16px] mt-1">
              {nodeInfo?.timestamp
                ? formatTimeMs(nodeInfo.timestamp)
                : "–"}
            </span>
          </div>
        );
      })}
    </div>
  );
}

export default function EventTimeline({
  events,
  activeTick,
  mode,
  markers,
  onJumpToEvent,
}: EventTimelineProps) {
  if (events.length === 0) {
    return (
      <div className="p-4 text-gray-400 text-center">
        Нет событий для этого трейса.
      </div>
    );
  }

  return (
    <ul className="overflow-auto max-h-full divide-y divide-gray-200">
      {events.map((event) => {
        const isActiveRow =
          mode === "replay" &&
          activeTick?.traceId === event.traceId;

        const isMarked = markers.some(
          (m) => m.eventId === event.traceId
        );

        return (
          <li
            key={event.traceId}
            className={cn(
              "px-2 py-2 transition-colors",
              isMarked &&
                mode === "replay" &&
                "cursor-pointer hover:bg-amber-100",
              isActiveRow && "bg-amber-200",
              isMarked && "border-l-4 border-amber-500"
            )}
            onClick={() => {
              if (isMarked && mode === "replay") {
                onJumpToEvent(event.traceId);
              }
            }}
          >
            {/* Верхняя строка */}
            <div className="flex items-center gap-3 mb-1">
              <span className="font-mono text-xs text-gray-500">
                {event.traceId}
              </span>
              <span className="text-xs font-semibold">
                {event.type}
              </span>
            </div>

            {/* Лампочки */}
            <PipelineRail
              event={event}
              activeTick={activeTick}
            />
          </li>
        );
      })}
    </ul>
  );
}
