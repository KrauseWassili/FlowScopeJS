import { useMemo, useState } from "react";
import EventTimeline from "./EventTimeline";
import { SystemMap } from "./SystemMap";
import { PlaybackPanel } from "./PlaybackPanel";
import { InlineEventInspector } from "./InlineEventInspector";

import { ObservedEvent } from "@/lib/events/observed/observedEvent.types";
import { ReplayTick } from "@/lib/events/replay/replay.types";
import { buildReplayTicks } from "@/lib/events/replay/buildReplayTicks";
import { useReplay } from "@/hooks/useReplay";
import { TraceEvent } from "@/lib/trace/sсhemas";
import { Marker } from "@/lib/markers";

type ObservationAreaProps = {
  events: ObservedEvent[];
  markers: Marker[];
  onJumpToEvent: (traceId: string) => void;
};

function findTraceEventForTick(
  tick: ReplayTick,
  events: ObservedEvent[]
): TraceEvent | null {
  const event = events.find((e) => e.traceId === tick.traceId);

  return event ? (event as unknown as TraceEvent) : null;
}

export default function ObservationArea({
  events,
  markers,
  onJumpToEvent,
}: ObservationAreaProps) {
  const allTicks = useMemo(() => buildReplayTicks(events), [events]);
  const replay = useReplay(allTicks);

  const [inspectedEvent, setInspectedEvent] = useState<{
    event: TraceEvent;
    node: string;
  } | null>(null);

  return (
    <div className="flex flex-col h-full">
      {/* Playback */}
      <PlaybackPanel
        mode={replay.mode}
        isPlaying={replay.isPlaying}
        replayIndex={replay.index}
        controls={replay.controls}
      />

      {/* System map */}
      <div className="h-1/2 overflow-auto border-b">
        <SystemMap
          mode={replay.mode}
          activeTick={replay.activeTick}
          allTicks={allTicks}
          onNodeClick={(tick) => {
            const event = findTraceEventForTick(tick, events);
            if (event) {
              setInspectedEvent({
                event,
                node: tick.node,
              });
            }
          }}
        />
      </div>

      {/* Inline inspector */}
      {inspectedEvent && (
        <InlineEventInspector
          event={inspectedEvent.event}
          node={inspectedEvent.node}
          onClose={() => setInspectedEvent(null)}
        />
      )}

      {/* Timeline */}
      <div className="h-1/2 min-h-0 overflow-auto">
        <EventTimeline
          events={events}
          mode={replay.mode}
          activeTick={replay.activeTick}
          markers={markers}
          onJumpToEvent={onJumpToEvent}
        />
      </div>
    </div>
  );
}
