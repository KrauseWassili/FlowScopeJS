import { TraceEvent } from "@/lib/trace/sсhemas";
import { eventSchemas } from "@/lib/trace/sсhemas";
import { z } from "zod";
import { formatTimeMs } from "@/lib/utils/formatTimeMs";
import { baseEventSchema } from "@/lib/trace/sсhemas/baseEventSchema";

type Props = {
  event: TraceEvent;
  node: string;
  onClose: () => void;
};

function renderValue(key: string, value: unknown) {
  if (value == null) return "—";

  if (key === "timestamp" && typeof value === "number") {
    return formatTimeMs(value);
  }

  if (typeof value === "object") {
    return (
      <pre className="max-h-32 overflow-auto rounded bg-gray-100 p-2 text-xs">
        {JSON.stringify(value, null, 2)}
      </pre>
    );
  }

  return String(value);
}

export function InlineEventInspector({ event, node, onClose }: Props) {
  const baseFields = Object.keys(baseEventSchema.shape);

  const nodeData =
    typeof event.node === "object"
      ? (event.node as Record<string, any>)[node]
      : {};

  const payloadSchema =
    eventSchemas[event.type as keyof typeof eventSchemas]?.shape
      .payload;

  const payloadFields =
    payloadSchema instanceof z.ZodObject
      ? Object.keys(payloadSchema.shape)
      : [];

  return (
    <div className="mt-3 rounded border bg-white shadow-sm text-sm">
      {/* Header */}
      <div className="flex justify-between items-center px-3 py-2 border-b">
        <div className="font-semibold">
          {event.type}
          <span className="ml-2 text-xs text-gray-500">
            @{node}
          </span>
        </div>

        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600"
        >
          ✕
        </button>
      </div>

      <div className="p-3 space-y-4">
        {/* Base event fields */}
        <div>
          <div className="font-semibold mb-1">
            Event
          </div>

          {baseFields.map((key) => (
            <div
              key={key}
              className="grid grid-cols-[140px_1fr] gap-2"
            >
              <div className="text-gray-500">{key}</div>
              <div className="font-mono text-xs">
                {renderValue(
                  key,
                  (event as any)[key]
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Node-specific */}
        <div>
          <div className="font-semibold mb-1">
            Node data
          </div>

          {Object.keys(nodeData).length === 0 ? (
            <div className="text-xs text-gray-400">
              —
            </div>
          ) : (
            Object.keys(nodeData).map((key) => (
              <div
                key={key}
                className="grid grid-cols-[140px_1fr] gap-2"
              >
                <div className="text-gray-500">{key}</div>
                <div className="font-mono text-xs">
                  {renderValue(
                    key,
                    nodeData[key]
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Payload */}
        {payloadFields.length > 0 && (
          <div>
            <div className="font-semibold mb-1">
              Payload
            </div>

            {payloadFields.map((key) => (
              <div
                key={key}
                className="grid grid-cols-[140px_1fr] gap-2"
              >
                <div className="text-gray-500">{key}</div>
                <div className="font-mono text-xs">
                  {renderValue(
                    key,
                    (event.payload as any)?.[key]
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
