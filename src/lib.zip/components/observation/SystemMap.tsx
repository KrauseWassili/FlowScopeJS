import { useMemo } from "react";
import {
  SYSTEM_NODES,
  EventNode,
} from "@/lib/events/nodes/systemNodes";
import { SystemEvent } from "./SystemEvent";
import { ReplayTick } from "@/lib/events/replay/replay.types";

type Props = {
  mode: "live" | "replay";
  activeTick: ReplayTick | null;
  allTicks: ReplayTick[];
  onNodeClick: (tick: ReplayTick) => void;
};

type NodeState = {
  active: boolean;
  outcome: "success" | "error" | null;
  blink: boolean;
};

const BLINK_WINDOW_MS = 200;

export function SystemMap({
  mode,
  activeTick,
  allTicks,
  onNodeClick,
}: Props) {
  const nodeState = useMemo(() => {
    const map = new Map<EventNode, NodeState>();
    const now = Date.now();

    // --- последний tick для каждой ноды (нужен для кликов в live) ---
    const lastTickByNode = new Map<EventNode, ReplayTick>();
    for (const tick of allTicks) {
      lastTickByNode.set(tick.node as EventNode, tick);
    }

    // --- базовая инициализация ---
    for (const node of SYSTEM_NODES) {
      map.set(node, {
        active: false,
        outcome: null,
        blink: false,
      });
    }

    if (mode === "replay") {
      // ▶️ REPLAY — активен ТОЛЬКО текущий tick
      if (activeTick) {
        const node = activeTick.node as EventNode;
        map.set(node, {
          active: true,
          outcome: activeTick.outcome,
          blink: false,
        });
      }
    } else {
      // 🟢 LIVE — финальное состояние + blink
      for (const tick of allTicks) {
        const node = tick.node as EventNode;
        const state = map.get(node)!;

        state.active = true;

        if (tick.outcome === "error") {
          state.outcome = "error";
        } else if (state.outcome !== "error") {
          state.outcome = "success";
        }

        // ✨ blink, если событие свежее
        if (now - tick.timestamp <= BLINK_WINDOW_MS) {
          state.blink = true;
        }
      }
    }

    return {
      map,
      lastTickByNode,
    };
  }, [mode, activeTick, allTicks]);

  return (
    <div className="relative w-full py-8">
      {/* НОДЫ */}
      <div className="flex justify-between px-6">
        {SYSTEM_NODES.map((node) => {
          const state = nodeState.map.get(node)!;

          return (
            <div key={node} className="flex flex-col items-center">
              <SystemEvent
                node={node}
                participated={state.active}
                outcome={state.outcome}
                blink={state.blink}
                onClick={() => {
                  const tick =
                    mode === "replay"
                      ? activeTick
                      : nodeState.lastTickByNode.get(node);

                  if (tick) {
                    onNodeClick(tick);
                  }
                }}
              />

              {/* вертикальное соединение — ВСЕГДА видно */}
              <div
                className={[
                  "w-px h-6 mt-2 transition-colors",
                  state.active
                    ? state.outcome === "error"
                      ? "bg-timeline-error"
                      : "bg-timeline-success"
                    : "bg-gray-300 opacity-30",
                ].join(" ")}
              />
            </div>
          );
        })}
      </div>

      {/* ШИНА */}
      <div className="relative mt-0">
        <div className="h-1 rounded mx-4 bg-gray-300" />
      </div>
    </div>
  );
}
