export type ReplayTick = {
  traceId: string;
  node: string;
  timestamp: number;
  outcome: "success" | "error";
};
