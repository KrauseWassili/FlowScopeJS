import { ObservedEvent } from "@/lib/events/observed/observedEvent.types";
import { ReplayTick } from "./replay.types";

export function buildReplayTicks(
  events: ObservedEvent[]
): ReplayTick[] {
  const ticks: ReplayTick[] = [];

  for (const event of events) {
    for (const [node, nodeInfo] of Object.entries(event.node ?? {})) {
      if (!nodeInfo?.timestamp) continue;

      ticks.push({
        traceId: event.traceId,
        node,
        timestamp: nodeInfo.timestamp,
        outcome: nodeInfo.outcome === "error" ? "error" : "success",
      });
    }
  }

  return ticks.sort((a, b) => a.timestamp - b.timestamp);
}
