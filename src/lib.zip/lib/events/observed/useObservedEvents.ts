import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import { ObservedEvent } from "./observedEvent.types";
import { EventNode } from "../nodes/systemNodes";

type IncomingSystemEvent = {
  traceId: string;
  type: string;
  node: EventNode;
  timestamp: number;
  outcome?: "success" | "error";
};

export function useObservedEvents(token: string | null) {
  const [events, setEvents] = useState<Record<string, ObservedEvent>>({});

  useEffect(() => {
    if (!token) return;

    const socket = io("http://localhost:4000", {
      auth: { token },
    });

    socket.on("system:event", (e: IncomingSystemEvent) => {
      // console.log("system:event", e);
      console.log("[OBS][FRONT]", e.node, e);
      setEvents((prev) => {
        const next = { ...prev };

        const event: ObservedEvent = next[e.traceId] ?? {
          traceId: e.traceId,
          type: e.type,
          node: {}, // 
        };

        event.node[e.node] = {
          timestamp: e.timestamp,
          outcome: e.outcome,
        };

        next[e.traceId] = { ...event };
        return next;
      });
    });

    return () => {
      socket.disconnect();
    };
  }, [token]);

  return Object.values(events);
}
