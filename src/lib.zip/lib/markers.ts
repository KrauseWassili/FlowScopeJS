export type Marker = {
    eventId: string;
    createdAt: Date;
}