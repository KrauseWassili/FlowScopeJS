
export default function page() {
  return (
    <div>
        FAQ
    </div>
  )
}
