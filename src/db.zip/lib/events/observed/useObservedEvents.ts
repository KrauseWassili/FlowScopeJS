import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { TraceEvent } from "@/lib/trace/sсhemas";

export function useObservedEvents(token: string | null) {
  const [events, setEvents] = useState<TraceEvent[]>([]);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!token) return;

    const socket = io("http://localhost:4000", {
      auth: { token },
    });

    socketRef.current = socket; // ✅ КЛЮЧЕВАЯ СТРОКА

    socket.on("system:history", (history: TraceEvent[]) => {
      setEvents(history);
    });

    socket.on("system:event", (event: TraceEvent) => {
      setEvents((prev) => {
        const isDuplicate = prev.some(
          (e) =>
            e.traceId === event.traceId &&
            e.node === event.node &&
            e.timestamp === event.timestamp
        );
        return isDuplicate ? prev : [...prev, event];
      });
    });

    socket.on("system:cleared", () => {
      console.log("[OBS] system:cleared");
      setEvents([]);
    });

    return () => {
      socketRef.current = null;
      socket.disconnect();
    };
  }, [token]);

  const clearEvents = () => {
    console.log("[OBS] emit system:clear");
    socketRef.current?.emit("system:clear");
  };

  return { events, clearEvents };
}
